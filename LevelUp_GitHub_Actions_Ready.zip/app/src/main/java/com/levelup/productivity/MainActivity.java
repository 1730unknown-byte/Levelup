package com.levelup.productivity;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    LevelUpView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,8,18));
        getWindow().setNavigationBarColor(Color.rgb(5,8,18));
        view = new LevelUpView(this);
        setContentView(view);
    }

    public void addTaskDialog() {
        final EditText input = new EditText(this);
        input.setHint("مثال: قراءة 20 صفحة");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setSingleLine(true);
        int pad = dp(20);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(pad,pad, pad, 0);
        box.addView(input, new FrameLayout.LayoutParams(-1,-2));

        AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("إضافة مهمة جديدة")
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("إضافة", null).create();

        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String s = input.getText().toString().trim();
                if(!s.isEmpty()) {
                    view.addTask(s, 20);
                    d.dismiss();
                }
            });
            input.requestFocus();
            d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        d.show();
        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.rgb(15,20,32)));
    }

    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}

class LevelUpView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    MainActivity a;
    android.content.SharedPreferences sp;
    int page=0;
    int level, xp, streak;
    String name;
    ArrayList<Task> tasks = new ArrayList<>();
    boolean levelUpFlash=false;

    int bg=Color.rgb(5,8,18), card=Color.rgb(13,19,31), card2=Color.rgb(18,27,43);
    int blue=Color.rgb(18,139,255), cyan=Color.rgb(31,202,255), white=Color.WHITE, muted=Color.rgb(160,174,194);
    RectF r = new RectF();

    LevelUpView(MainActivity c){
        super(c); a=c;
        sp=c.getSharedPreferences("data",0);
        name=sp.getString("name","Sami");
        level=sp.getInt("level",7);
        xp=sp.getInt("xp",720);
        streak=sp.getInt("streak",12);
        loadTasks();
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
    }

    static class Task {
        String title; int xp; boolean done;
        Task(String t,int x,boolean d){title=t;xp=x;done=d;}
    }

    void loadTasks(){
        tasks.clear();
        int n=sp.getInt("task_count",-1);
        if(n<0){
            tasks.add(new Task("تمرين 30 دقيقة",20,false));
            tasks.add(new Task("قراءة 20 صفحة",15,false));
            tasks.add(new Task("شرب 2 لتر ماء",10,false));
            tasks.add(new Task("تعلم مهارة 30 دقيقة",30,false));
            saveTasks();
        } else {
            for(int i=0;i<n;i++){
                tasks.add(new Task(sp.getString("t"+i,"مهمة"),sp.getInt("x"+i,20),sp.getBoolean("d"+i,false)));
            }
        }
    }

    void saveTasks(){
        android.content.SharedPreferences.Editor e=sp.edit();
        e.putInt("task_count",tasks.size());
        for(int i=0;i<tasks.size();i++){
            Task t=tasks.get(i);
            e.putString("t"+i,t.title).putInt("x"+i,t.xp).putBoolean("d"+i,t.done);
        }
        e.apply();
        e.putInt("level",level).putInt("xp",xp).putInt("streak",streak).putString("name",name).apply();
    }

    void addTask(String s,int x){
        tasks.add(new Task(s,x,false)); saveTasks(); invalidate();
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawColor(bg);
        if(page==0) drawHome(c);
        else if(page==1) drawTasks(c);
        else if(page==2) drawCharacter(c);
        else if(page==3) drawAchievements(c);
        else drawSettings(c);
        drawNav(c);
        if(levelUpFlash) drawLevelUp(c);
    }

    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(s,x,y,p);
    }
    void rtl(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(s,x,y,p);
    }
    void center(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(size); p.setColor(color);
        p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
        c.drawText(s,x,y,p);
    }
    void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){
        p.setStyle(Paint.Style.FILL);p.setColor(color);p.setShadowLayer(0,0,0,0);
        r.set(l,t,rr,bb);c.drawRoundRect(r,rad,rad,p);
    }
    void line(Canvas c,float x1,float y1,float x2,float y2,int color,float sw){
        p.setColor(color);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);
    }
    void progress(Canvas c,float x,float y,float w,float h,float val,int color){
        round(c,x,y,x+w,y+h,h/2,Color.rgb(35,48,65));
        round(c,x,y,x+w*Math.max(0,Math.min(1,val)),y+h,h/2,color);
    }

    void header(Canvas c,String title){
        center(c,title,getWidth()/2f,42,20,white,true);
    }

    void drawHome(Canvas c){
        header(c,"LevelUp");
        text(c,"☰",24,43,25,white,false);
        text(c,"♟",getWidth()-42,43,24,cyan,false);

        round(c,18,62,getWidth()-18,150,20,card);
        text(c,"●",34,97,38,cyan,true);
        text(c,name,86,91,23,white,true);
        text(c,"المستوى "+level,86,118,14,muted,false);
        center(c,"D",getWidth()-62,105,28,cyan,true);
        text(c,"XP",34,139,11,muted,true);
        progress(c,63,130,getWidth()-115,8,(xp%1000)/1000f,blue);
        rtl(c,xp+" / 1000",getWidth()-35,145,11,muted,false);

        round(c,18,165,getWidth()-18,410,18,card);
        rtl(c,"الإحصائيات",getWidth()-35,195,18,white,true);
        stat(c,"القوة",18,220, blue);
        stat(c,"الذكاء",22,252, cyan);
        stat(c,"اللياقة",15,284, blue);
        stat(c,"الانضباط",20,316, cyan);
        stat(c,"الصحة",85,348, Color.rgb(30,190,105));

        round(c,18,425,getWidth()-18,650,18,card);
        rtl(c,"مهام اليوم",getWidth()-35,455,18,white,true);
        int y=480;
        for(int i=0;i<Math.min(4,tasks.size());i++){
            Task t=tasks.get(i);
            round(c,30,y-20,getWidth()-30,y+25,12,card2);
            text(c,t.done?"✓":"○",42,y+10,18,t.done?Color.GREEN:white,true);
            rtl(c,t.title,getWidth()-75,y+5,13,white,false);
            text(c,"+"+t.xp+" XP",getWidth()-155,y+5,11,cyan,true);
            y+=43;
        }

        round(c,18,665,getWidth()-18,735,16,card);
        center(c,"🔥 "+streak,getWidth()/2f-75,708,19,white,true);
        center(c,"⭐ "+(xp+120),getWidth()/2f+75,708,19,white,true);
    }

    void stat(Canvas c,String s,int value,int y,int color){
        rtl(c,s,getWidth()-190,y,13,white,false);
        progress(c,getWidth()-175,y-12,115,8,value/100f,color);
        rtl(c,""+value,getWidth()-38,y,13,white,true);
    }

    void drawTasks(Canvas c){
        header(c,"المهام");
        int y=75;
        round(c,18,y,getWidth()-18,y+50,15,card);
        center(c,"اليومية",getWidth()/2f,y+31,14,white,true);
        y+=70;
        for(int i=0;i<tasks.size();i++){
            Task t=tasks.get(i);
            round(c,18,y,getWidth()-18,y+68,16,card);
            text(c,t.done?"✓":"○",35,y+40,22,t.done?Color.rgb(40,210,120):white,true);
            rtl(c,t.title,getWidth()-60,y+28,14,white,true);
            rtl(c,"+"+t.xp+" XP",getWidth()-60,y+50,11,cyan,false);
            y+=78;
            if(y>getHeight()-170) break;
        }
        round(c,18,getHeight()-170,getWidth()-18,getHeight()-115,15,blue);
        center(c,"+  إضافة مهمة جديدة",getWidth()/2f,getHeight()-136,15,white,true);
    }

    void drawCharacter(Canvas c){
        header(c,"الشخصية");
        center(c,"✦",getWidth()/2f,120,85,cyan,true);
        center(c,name,getWidth()/2f,160,24,white,true);
        center(c,"مبتدئ",getWidth()/2f,184,13,muted,false);
        progress(c,45,205,getWidth()-90,9,(xp%1000)/1000f,blue);
        center(c,level+" المستوى",getWidth()/2f,235,14,white,true);

        round(c,18,255,getWidth()-18,355,18,card);
        center(c,"الرتبة الحالية",getWidth()/2f-90,282,12,muted,false);
        center(c,"D",getWidth()/2f-90,323,38,cyan,true);
        center(c,"الرتبة التالية",getWidth()/2f+90,282,12,muted,false);
        center(c,"C",getWidth()/2f+90,323,38,muted,true);

        round(c,18,375,getWidth()-18,485,18,card);
        center(c,"🔥 "+streak+" يوم",getWidth()/2f-85,418,16,white,true);
        center(c,"⭐ "+xp+" XP",getWidth()/2f+85,418,16,white,true);
        center(c,"سلسلة الإنجاز",getWidth()/2f-85,447,11,muted,false);
        center(c,"إجمالي XP",getWidth()/2f+85,447,11,muted,false);
    }

    void drawAchievements(Canvas c){
        header(c,"إنجازات");
        int y=72;
        String[][] ach={{"بداية الرحلة","أكمل أول مهمة","50"},{"أسبوع مثالي","حافظ على سلسلة 7 أيام","100"},{"منضبط","أكمل 50 مهمة","80"},{"لا شيء مستحيل","أنجز 100 مهمة","150"},{"أسطورة قادمة","وصل إلى المستوى 20","200"}};
        for(int i=0;i<ach.length;i++){
            round(c,18,y,getWidth()-18,y+82,16,card);
            text(c,"✦",34,y+47,28,cyan,true);
            rtl(c,ach[i][0],getWidth()-58,y+30,15,white,true);
            rtl(c,ach[i][1],getWidth()-58,y+53,11,muted,false);
            text(c,"💎 "+ach[i][2],getWidth()-100,y+72,10,cyan,true);
            y+=92;
        }
    }

    void drawSettings(Canvas c){
        header(c,"الإعدادات");
        round(c,18,70,getWidth()-18,140,18,card);
        rtl(c,"الشخصية الحالية",getWidth()-35,98,15,white,true);
        rtl(c,name,getWidth()-35,123,13,muted,false);
        round(c,18,155,getWidth()-18,220,18,card);
        rtl(c,"إضافة شخصية",getWidth()-35,195,15,white,true);
        round(c,18,235,getWidth()-18,300,18,card);
        rtl(c,"تصفير التقدم",getWidth()-35,275,15,white,true);
    }

    void drawNav(Canvas c){
        int y=getHeight()-85;
        round(c,0,y,getWidth(),getHeight(),0,Color.rgb(7,11,21));
        String[] labels={"الرئيسية","المهام","الشخصية","إنجازات","الإعدادات"};
        String[] icons={"⌂","✓","●","♛","⚙"};
        int w=getWidth()/5;
        for(int i=0;i<5;i++){
            int x=w*i+w/2;
            int col=(page==i)?cyan:muted;
            center(c,icons[i],x,y+27,21,col,true);
            center(c,labels[i],x,y+53,10,col,page==i);
        }
    }

    void drawLevelUp(Canvas c){
        p.setColor(Color.argb(205,0,0,0));c.drawRect(0,0,getWidth(),getHeight(),p);
        round(c,30,180,getWidth()-30,510,26,Color.rgb(11,22,40));
        center(c,"✦",getWidth()/2f,255,70,cyan,true);
        center(c,"LEVEL UP!",getWidth()/2f,310,30,white,true);
        center(c,"لقد وصلت إلى المستوى "+level, getWidth()/2f,345,16,white,true);
        center(c,"+5 نقاط مهارة",getWidth()/2f,378,15,cyan,true);
        center(c,"+50 XP",getWidth()/2f,407,17,cyan,true);
        round(c,65,435,getWidth()-65,480,12,blue);
        center(c,"رائع!",getWidth()/2f,464,15,white,true);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX(), y=e.getY();

        if(levelUpFlash){
            levelUpFlash=false; invalidate(); return true;
        }

        int navY=getHeight()-95;
        if(y>=navY){
            int i=(int)(x/(getWidth()/5f));
            if(i<0)i=0;if(i>4)i=4;
            page=i; invalidate(); return true;
        }

        if(page==1 && y>=getHeight()-185 && y<=getHeight()-100){
            a.addTaskDialog(); return true;
        }

        if(page==1 && y>120){
            int idx=(int)((y-145)/78);
            if(idx>=0 && idx<tasks.size()){
                Task t=tasks.get(idx);
                if(!t.done){
                    t.done=true; gainXP(t.xp);
                    saveTasks(); invalidate();
                }
            }
        }

        return true;
    }

    void gainXP(int amount){
        xp+=amount;
        if(xp>=1000){
            xp-=1000; level++; levelUpFlash=true;
        }
        saveTasks();
    }
}
